{-# LANGUAGE TupleSections #-}
module StandardGraph where

import qualified Data.Set as S

{-
    Graf ORIENTAT cu noduri de tipul a, reprezentat prin mulțimile (set)
    de noduri și de arce.

    Mulțimile sunt utile pentru că gestionează duplicatele și permit
    testarea egalității a două grafuri fără a ține cont de ordinea nodurilor
    și a arcelor.

    type introduce un sinonim de tip, similar cu typedef din C.
-}
type StandardGraph a = (S.Set a, S.Set (a, a))
 -- data StandardGraphT = StandardGraphC {
--     nodes :: S.Set a,
--     edges :: S.Set (a, a)
-- } deriving (Eq, Show)

{-
    *** TODO ***

    Construiește un graf pe baza listelor de noduri și de arce.

    Hint: S.fromList.

    Constrângerea (Ord a) afirmă că valorile tipului a trebuie să fie
    ordonabile, lucru necesar pentru reprezentarea internă a mulțimilor.
    Este doar un detaliu, cu care nu veți opera explicit în această etapă.
    Veți întâlni această constrângere și în tipurile funcțiilor de mai jos.
-}
fromComponents :: Ord a
               => [a]              -- lista nodurilor
               -> [(a, a)]         -- lista arcelor
               -> StandardGraph a  -- graful construit
fromComponents ns es = (S.fromList ns, S.fromList es)
-- fromComponents2 ns es = StandardGraphC {
--     nodes = S.fromList ns,
--     edges = S.fromList es
-- }

{-
    *** TODO ***

    Mulțimea nodurilor grafului.
-}
nodes :: StandardGraph a -> S.Set a
nodes = fst 
--nodes Empty = S.empty
--nodes (Node a) = S.insert a S.empty
--nodes (Overlay a b) = S.union (nodes a) (nodes b)
--nodes (Connect a b) = S.union (nodes a) (nodes b)

{-
    *** TODO ***

    Mulțimea arcelor grafului.
-}
edges :: StandardGraph a -> S.Set (a, a)
edges = snd
--edges Empty = S.empty
--edges (Node a) = S.empty
--edges (Overlay a b) = S.union (edges a) (edges b)
--edges (Connect a b) = S.union (S.union (S.cartesianProduct (nodes a) (nodes b)) (edges a)) (edges b)

{-
    Exemple de grafuri
-}
graph1 :: StandardGraph Int
graph1 = fromComponents [1, 2, 3, 3, 4] [(1, 2), (1, 3), (1, 2)]

graph2 :: StandardGraph Int
graph2 = fromComponents [4, 3, 3, 2, 1] [(1, 3), (1, 3), (1, 2)]

graph3 :: StandardGraph Int
graph3 = fromComponents [1, 2, 3, 4] [(1, 2), (1, 4), (4, 1), (2, 3), (1, 3)]

graph4 :: StandardGraph Int
graph4 = fromComponents [1, 2, 3, 4] [(1, 2), (1, 4), (4, 1), (2, 4), (1, 3)]

shouldBeTrue :: Bool
shouldBeTrue = graph1 == graph2

{-
    *** TODO ***

    Mulțimea nodurilor înspre care pleacă arce dinspre nodul curent.

    Exemplu:

    > outNeighbors 1 graph3
    fromList [2,3,4]
-}
outNeighbors :: Ord a => a -> StandardGraph a -> S.Set a
outNeighbors node graph = (S.map snd (S.filter (\(n1, n2) -> (n1 == node)) (snd graph)))

--S.fromList $ map snd $ filter (\(x,y) -> x == node) $ S.toList $ edges graph

{-
    *** TODO ***

    Mulțimea nodurilor dinspre care pleacă arce înspre nodul curent.

    Exemplu:

    > inNeighbors 1 graph3 
    fromList [4]
-}
inNeighbors :: Ord a => a -> StandardGraph a -> S.Set a
inNeighbors node graph = (S.map fst (S.filter (\(n1, n2) -> (n2 == node)) (snd graph)))

{-
    *** TODO ***

    Întoarce graful rezultat prin eliminarea unui nod și a arcelor în care
    acesta este implicat. Dacă nodul nu există, întoarce același graf.

    Exemplu:

    > removeNode 1 graph3
    (fromList [2,3,4],fromList [(2,3)])
-}

removeEdges node graph = (S.filter (\(n1, n2) -> (not ((n1 == node) || (n2 == node)))) (snd graph))
removeNodes node graph = (S.filter (\n -> (not (n == node))) (fst graph))

removeNode :: Ord a => a -> StandardGraph a -> StandardGraph a
removeNode node graph = ((removeNodes node graph), (removeEdges node graph))

{-
    *** TODO ***

    Divizează un nod în mai multe noduri, cu eliminarea nodului inițial.
    Arcele în care era implicat vechiul nod trebuie să devină valabile
    pentru noile noduri.

    Exemplu:

    > splitNode 2 [5,6] graph3
    (fromList [1,3,4,5,6],fromList [(1,3),(1,4),(1,5),(1,6),(4,1),(5,3),(6,3)])
-}

splitNodes old news graph = (S.union (S.filter (\node -> (not (node == old))) (fst graph)) (S.fromList news))

splitWithoutOld old news graph = (S.filter (\(n1, n2) -> (not ((n1 == old) || (n2 == old)))) (snd graph))
splitOldOnFirst old news graph = [(x, y) | y <- (S.toList (S.map snd (S.filter (\(n1, n2) -> (n1 == old)) (snd graph)))), x <- news]
splitOldOnSecond old news graph = [(x, y) | x <- (S.toList (S.map fst (S.filter (\(n1, n2) -> (n2 == old)) (snd graph)))), y <- news]

splitEdges1 old news graph = (S.union (S.fromList (splitOldOnFirst old news graph)) (S.fromList (splitOldOnSecond old news graph)))
splitEdges2 old news graph = (S.union (splitWithoutOld old news graph) (splitEdges1 old news graph))

splitNode :: Ord a
          => a                -- nodul divizat
          -> [a]              -- nodurile cu care este înlocuit
          -> StandardGraph a  -- graful existent
         -> StandardGraph a  -- graful obținut
splitNode old news graph = if null news then (removeNode old graph)
                                        else ((splitNodes old news graph), (splitEdges2 old news graph))

{-
    *** TODO ***

    Îmbină mai multe noduri într-unul singur, pe baza unei proprietăți
    respectate de nodurile îmbinate, cu eliminarea acestora. Arcele în care
    erau implicate vechile noduri vor referi nodul nou.

    Exemplu:

    > mergeNodes even 5 graph3
    (fromList [1,3,5],fromList [(1,3),(1,5),(5,1),(5,3)])
-}

mergeNode prop node graph = (S.union (S.filter (\node -> (not (prop node))) (fst graph)) (S.fromList [node]))

mergeNotProp prop node graph = (S.filter (\(n1, n2) -> (not ((prop n1) || (prop n2)))) (snd graph))
mergePropOnFirst prop node graph = [(x, y) | x <- [node], y <- (S.toList (S.map snd (S.filter (\(n1, n2) -> ((prop n1) && (not (prop n2)))) (snd graph))))]
mergePropOnSecond prop node graph = [(x, y) | y <- [node], x <- (S.toList (S.map fst (S.filter (\(n1, n2) -> ((prop n2) && (not (prop n1)))) (snd graph))))]

mergeEdges1 prop node graph = (S.union (S.fromList (mergePropOnFirst prop node graph)) (S.fromList (mergePropOnSecond prop node graph)))
mergeEdges2 prop node graph = (S.union (mergeNotProp prop node graph) (mergeEdges1 prop node graph))

mergeNodes :: Ord a
           => (a -> Bool)      -- proprietatea îndeplinită de nodurile îmbinate
           -> a                -- noul nod
           -> StandardGraph a  -- graful existent
           -> StandardGraph a  -- graful obținut
mergeNodes prop node graph
    | (length (S.filter (\n -> (prop n)) (fst graph))) == 0 = graph
    | (length (S.filter (\(n1, n2) -> ((prop n1) && (prop n2))) (snd graph))) > 0 =  
        ((mergeNode prop node graph), (S.union (mergeEdges2 prop node graph) (S.fromList([(node, node)]))))
    | otherwise = ((mergeNode prop node graph), (mergeEdges2 prop node graph))  
